<?php
namespace System;

use System\CraynerSystem;

/**
* @author Ammar Faizi <ammarfaizi2@gmail.com> https://www.facebook.com/ammarfaizi2
* @license RedAngel PHP Concept
*/
class CraynerMachine extends CraynerSystem
{
    public function __construct()
    {
    }
}
